<?php

namespace App\Http\Controllers\Api;

use App\Models\Label;
use App\Models\Plan;
use App\Models\Recovery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class IndexController extends Controller
{
   public function store(Request $request){
      $data = $request->all();
      $validator = Validator::make($data, [
          'type' => 'required|in:1,2',
      ],[
          'type.required' => '缺少类型参数',
          'label.required' => '缺少标签参数',
          'type.in' => '类型参数有误',
      ]);
      if(!$validator->passes()){
         return response()->json([
             'message' => $validator->errors()->first()
         ], 400);
      }

      $labels = json_decode($data['label']);
      if(!is_array($labels))
         return response()->json([
             'message' => '标签参数格式有误'
         ], 400);
      if($data['type'] == 1){//标签入库
         $old_labels = Label::pluck('number')->toArray();
         foreach($labels as $k=>$v){
            if(!in_array($v, $old_labels)){
               $Label = new Label();
               $Label->fill(['number'=>$v]);
               $Label->save();
            }
         }
      }else{//样品回收
         $plan = Plan::where('status', 1)->first();
         if(!$plan){
            return response()->json([
                'message' => '暂无样品回收计划'
            ], 400);
         }
         $old_recovery = Recovery::whereBetween('created_at', [strtotime($plan['created_at']), time()])->pluck('number')->toArray();
         foreach($labels as $k=>$v){
            if(!in_array($v, $old_recovery)){
               $Recovery = new Recovery();
               $Recovery->fill(['number' => $v, 'plan_id' => $plan['id']]);
               $Recovery->save();
            }
         }
         $plan->step = 1;//改为回收阶段
         $plan->save();
      }
      return response()->json([
          'message' => '成功',
      ]);
   }
}
