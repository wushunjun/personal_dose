<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{

    const ON = 1;//开启
    const OFF = 2;//关闭


    protected $guarded = ['_token'];

    //public $timestamps = false;//关闭自动维护

    public  function  setCreatedAtAttribute($value)
    {
        $this->attributes['created_at'] = strtotime($value);
    }

    public  function  setUpdatedAtAttribute($value)
    {
        $this->attributes['updated_at'] = strtotime($value);
    }

    public static $statusText = [
        self::OFF => '<label class="label label-default">已关闭</label>',
        self::ON => '<label class="label label-success">已开启</label>',
    ];

    public function recovery(){
        return $this->hasMany(Recovery::class, 'plan_id', 'id');
    }
}
